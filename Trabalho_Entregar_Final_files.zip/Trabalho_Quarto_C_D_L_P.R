### Regras de Associação 
pacman::p_load(
  arules, arulesCBA, arulesViz, caret, dplyr, corrplot, ggplot2, rattle,plotly
)

# Lê o arquivo CSV e cria o DataFrame
caminho_arquivo <- "C:/Users/Paulo Almeida/Desktop/fafire/2023/EstatisticaComputacionalR/git/controleVersao/BasesEx/Base_Jan_20_23_novo.csv"

# Lê o arquivo CSV e cria o DataFrame
dados_df <- read.csv(caminho_arquivo, sep = ";")

# Idetificando o  nomes das colunas
nomes_colunas <- names(dados_df)
print(nomes_colunas)

# Excluindo as variáveis que não serão analisadas
dados_df2 <- dados_df %>% select(-CODFISCAL, -SITTRIBUT) 

# CRIANDO DATAFRAME 3 (FILIAL, TOTAL)
dados_df3 <- dados_df %>% select(FILIAL, TOTAL,DESCRICAO)

# Remove linhas com valores NA em PRECOVENDA
dados_df3 <- dados_df3[!is.na(dados_df3$TOTAL),]
####-------

# Substituir do Dataframe 'dados_df3' na coluna 'PRECOVENDA' é uma coluna numérica em formato de caracteres
dados_df3$TOTAL <- as.numeric(gsub(",", ".", as.character(dados_df3$TOTAL)))

str(dados_df3$TOTAL)

unique(dados_df3$DESCRICAO)

# Calcula a média de PRECOVENDA para cada FILIAL
media_preco_por_filial <- tapply(dados_df3$TOTAL, dados_df3$FILIAL, mean)
print(media_preco_por_filial)

Filiais <- c("Filial   6", "Filial   9", "Filial 13")
dados <- data.frame(filiais, media_preco_por_filial)

grafico_pizza <- ggplot(dados, aes(x = "", y = media_preco_por_filial, fill = Filiais)) +
  geom_bar(stat = "identity", width = 1) +
  coord_polar("y") +
  theme_void() +
  theme(legend.position = "left") +
  ggtitle("Média de Preço por Filial")


# Exiba o gráfico
print(grafico_pizza)
#install.packages("dplyr")

# Summary
associacaoDADOS <- apriori(dados_df)
summary(associacaoDADOS)


################################################ CRIANDO DATAFRAME 4 (PROD,DESCRICAO,TOTAL)
library(dplyr)
dados_df4 <- dados_df %>% select(PROD,DESCRICAO,TOTAL)
# Remove linhas com valores NA em PRECOVENDA
dados_df4 <- dados_df4[!is.na(dados_df4$TOTAL),]
dados_df4$TOTAL <- as.numeric(gsub(",", ".", as.character(dados_df4$TOTAL)))

# Agrupe os dados por produto e calcule a soma das vendas (total_sales) para cada produto
summarized_data <- dados_df4 %>%
  group_by(PROD, DESCRICAO) %>%
  summarise(Total = sum(TOTAL))

sorted_data <- summarized_data %>%
  arrange(desc(Total))

# Ordene os produtos pela quantidade de vendas em ordem decrescente
sorted_data <- summarized_data %>%
  arrange(desc(Total))

# Selecione os top 10 produtos mais vendidos
top_10_products <- head(sorted_data, 10)
top_10_products$Total <- sprintf("R$ %.2f", top_10_products$Total)

# Exiba o DataFrame com os top 10 produtos mais vendidos
print(top_10_products)

##################################################3 CRIANDO DATAFRAME 5 (PROD,DESCRICAO,QT)
library(dplyr)
dados_df5 <- dados_df %>% select(PROD,DESCRICAO,QT)
# Remove linhas com valores NA em PRECOVENDA
dados_df5 <- dados_df5[!is.na(dados_df5$QT),]
dados_df5$QT <- as.numeric(gsub(",", ".", as.character(dados_df5$QT)))

# Agrupe os dados por produto e calcule a soma das vendas (total_sales) para cada produto
summarized_data <- dados_df5 %>%
  group_by(PROD, DESCRICAO) %>%
  summarise(QUANTIDADE = sum(QT))

#sorted_data <- summarized_data %>%
#  arrange(desc(QUANTIDADE))

# Ordene os produtos pela quantidade de vendas em ordem decrescente
sorted_data <- summarized_data %>%
  arrange(desc(QUANTIDADE))

# Selecione os top 10 produtos mais vendidos
top_10_products <- head(sorted_data, 20)
#top_10_products$QUANTIDADE <- sprintf("R$ %.2f", top_10_products$QUANTIDADE)

# Exiba o DataFrame com os top 10 produtos mais vendidos
print(top_10_products)

############################################### CRIANDO DATAFRAME 6 (CODEPTO,DESCRICAODEPTO,QT)
library(dplyr)
dados_df6 <- dados_df %>% select(CODEPTO,DESCRICAODEPTO,QT)
# Remove linhas com valores NA em PRECOVENDA
dados_df6 <- dados_df6[!is.na(dados_df6$QT),]
dados_df6$QT <- as.numeric(gsub(",", ".", as.character(dados_df6$QT)))

# Agrupe os dados por produto e calcule a soma das vendas (total_sales) para cada produto
summarized_data <- dados_df6 %>%
  group_by(CODEPTO, DESCRICAODEPTO) %>%
  summarise(QUANTIDADE = sum(QT))

#sorted_data <- summarized_data %>%
#  arrange(desc(QUANTIDADE))

# Ordene os produtos pela quantidade de vendas em ordem decrescente
sorted_data <- summarized_data %>%
  arrange(desc(QUANTIDADE))

# Selecione os top 10 produtos mais vendidos
top_10_products <- head(sorted_data, 5)
#top_10_products$QUANTIDADE <- sprintf("R$ %.2f", top_10_products$QUANTIDADE)

# Exiba o DataFrame com os top 5 produtos mais vendidos
print(top_10_products)

##  Grafico_Barra_Vertical
library(ggplot2)
DEPTO <- unique(top_10_products$DESCRICAODEPTO)
dados2 <- data.frame(top_10_products$QUANTIDADE)

grafico_barras <- ggplot(top_10_products, aes(x = DEPTO, y = QUANTIDADE)) +
  geom_bar(stat = "identity") +
  xlab("Departamentos") +
  ylab("Quantidade") +
  ggtitle("Gráfico de Barras Verticais")

# Exibir o gráfico
print(grafico_barras)

##Grafico Pizza

grafico_pizza <- ggplot(top_10_products, aes(x = "", y = QUANTIDADE, fill = DEPTO)) +
  geom_bar(stat = "identity", width = 1) +
  coord_polar("y") +
  theme_void() +
  theme(legend.position = "left") +
  ggtitle("Média de Preço por Filial")
# Exiba o gráfico
print(grafico_pizza)

# TABELA DE CORRELAÇÃO COM TODAS AS VARIÁVEIS #
correlacao <- cor(dados_df3$FILIAL, dados_df3$TOTAL)
print(correlacao)

#_________________
VALOR <- dados_df3$TOTAL
plot(VALOR)

library(ggplot2)

# Criar um data frame com FILIAL e TOTAL
media_df <- data.frame(media_preco_por_filial)

library(datasets)

# Crie um gráfico de dispersão usando as variáveis Filial e Total
plot(dados_df3$FILIAL, dados_df3$TOTAL, 
     xlab = "Filial", ylab = "Total", 
     main = "Gráfico de Dispersão de FILIAL vs. TOTAL")

####################################CRIANDO DATAFRAME 7 (CODEPTO,DESCRICAODEPTO,QT) 

dados_df7 <- dados_df %>% select(USUARIO,TOTAL)
# Remove linhas com valores NA em PRECOVENDA
dados_df7 <- dados_df7[!is.na(dados_df7$TOTAL),]
dados_df7$TOTAL <- as.numeric(gsub(",", ".", as.character(dados_df7$TOTAL)))

# Agrupe os dados por produto e calcule a soma das vendas (total_sales) para cada produto
summarized_data <- dados_df7 %>%
  group_by(USUARIO) %>%
  summarise(Total = sum(TOTAL))

sorted_data <- summarized_data %>%
  arrange(desc(Total))

# Ordene os produtos pela quantidade de vendas em ordem decrescente
sorted_data <- summarized_data %>%
  arrange(desc(Total))
sorted_data_m <- summarized_data %>%
  arrange((Total))

# Selecione os top 10 produtos mais vendidos
top_5melhores_vend <- head(sorted_data, 5)
top_5piores_vend <- head(sorted_data_m, 5)
#top_5melhores_vend$Total <- sprintf("R$ %.2f", top_5melhores_vend$Total)
#top_5piores_vend$Total <- sprintf("R$ %.2f", top_5piores_vend$Total)

# Exiba o DataFrame com os top 10 produtos mais vendidos
print(top_5melhores_vend)
print(top_5piores_vend)


# Criar o gráfico de barras

grafico <- ggplot(top_5melhores_vend, aes(x = reorder(USUARIO,Total), y = Total)) +
  geom_bar(stat = "identity", fill = "green", alpha = 0.6) +
  geom_text(aes(label = Total), vjust = -0.2) +
  coord_flip() +  # Inverte os eixos
  xlab("Usuários") +
  ylab("Total") +
  ggtitle("Top 5 Melhores")

grafico2 <- ggplot(top_5piores_vend, aes(x = reorder(USUARIO, Total), y = Total)) +
  geom_bar(stat = "identity", fill = "red", alpha = 0.6) +
  geom_text(aes(label = Total), vjust = -0.2) +
  coord_flip() +  # Inverte os eixos
  xlab("Usuários") +
  ylab("Total") +
  ggtitle("Top 5 Piores")

# Exiba o gráfico
print(grafico)
print(grafico2)

####################################CRIANDO DATAFRAME 8 (PROD,TOTAL,USUARIO,FILIAL) 

# Tabela de correlaçao
dados_df8 <- dados_df %>% select(PROD,TOTAL,USUARIO,FILIAL)
dados_df8$TOTAL <- as.numeric(gsub(",", ".", as.character(dados_df8$TOTAL))) # Correção trocando o , por .#
cor(dados_df8) 

####################################CRIANDO DATAFRAME 9 (PROD,TOTAL,USUARIO,FILIAL) 


dados_df9 <- dados_df %>% select(DATA,TOTAL)
# Remove linhas com valores NA em PRECOVENDA
dados_df9 <- dados_df9[!is.na(dados_df9$TOTAL),]

dados_df9$TOTAL <- as.numeric(gsub(",", ".", as.character(dados_df9$TOTAL)))
dados_df9$TOTAL <- as.numeric(dados_df9$TOTAL)
media_preco_por_data <- tapply(dados_df9$TOTAL, dados_df9$DATA, mean)
print(media_preco_por_data)

dados_df9$DATA <- as.character(dados_df9$DATA)
#dados_df9$TOTAL <- sprintf("R$ %.2f", dados_df9$TOTAL)

soma_total_por_data <- dados_df9 %>% group_by(DATA) %>% summarise(SOMA_TOTAL = sum(TOTAL, na.rm = TRUE))

# Print the result
print(soma_total_por_data)

#new
# Pré-processamento
dados_dfParticao = createDataPartition(1:nrow(dados_df), p= .7) # cria a partição 70-30 1:nrow toda a base, de 1:50 as 50 primeiras linhas.
treinodados_df = dados_df[dados_dfParticao$Resample1, ] # treino Os 70%
testedados_df = dados_df[-dados_dfParticao$Resample1, ] # - treino = teste a base sem os 70% "-"

# Mineração e predição com Árvores de Decisão
## Árvore de Decisão
#library(rpart.plot)
testedados_df$TOTAL <- as.numeric(gsub(",", ".", as.character(testedados_df$TOTAL)))
testedados_df$TOTAL <- as.numeric(gsub(",", ".", as.character(testedados_df$TOTAL)))

dados_df_RPART <- train(
  FILIAL  ~  PROD + QT + DATA + SITTRIBUT + CODEPTO , 
  data = treinodados_df, 
  method = "rpart", 
  trControl = trainControl(method = "cv"))

fancyRpartPlot(dados_df_RPART$finalModel) # desenho da árvore
plot(varImp(dados_df_RPART)) # importância das variáveis

varImp(dados_df_RPART, scale = T) # importância de cada variável

predicaoTree = predict(dados_df_RPART, newdata = testedados_df)


postResample(testedados_df[ , 10], predicaoTree) # teste de performance da Árvore Condicional  RMSE - Erro quadratico Medio Melhor metrica a ser usada(quanto menor melhor), RDquared - Erro quandrado o quanto ele usou para a analise(quanto maior melhor), MAE - erro absoluto (+/-) (quanto menor melhor).

#Gráfico de densidade
dados_df %>% ggplot(aes(x = FILIAL)) + geom_density()  +
  theme(panel.background = element_rect(fill = "white"),
        panel.border = element_rect(fill = NA,color = "black",linetype = "dashed", size = 1)) 


# Mostrar o gráfico interativo
gg <- ggplot(dados_df9, aes(x = DATA, y = TOTAL, text = paste("Data: ", DATA, "<br>Total: ", TOTAL))) +
  geom_point() + theme(panel.background = element_rect(fill = "white"),
                       panel.border = element_rect(fill = NA,color = "black",linetype = "dashed", size = 1))  +
  labs(x = "Data", y = "Total")

gg_inter <- ggplotly(gg)

print (gg_inter)

########## # Mostrar o gráfico interativo 2

dados_df10 <- dados_df %>% select(PROD,DATA,TOTAL,USUARIO,FILIAL,QT)
dados_df10$FILIAL <-  as.factor(dados_df10$FILIAL)
dados_df10$PROD <-  as.integer(dados_df10$PROD)

gg2 <- ggplot(dados_df10, aes(x = PROD,y = QT , color = FILIAL)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE)

gg3 <- ggplotly(gg2)
gg3

